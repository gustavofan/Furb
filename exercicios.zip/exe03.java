import java.util.Scanner;

public class exe03 { 

    public static void main(String[] args) {
        Scanner scanner = new Scanner (System.in);

        double precoLitro = 5.76;
        
        System.out.println("Informe o valor do pagamento");
        double valorPagamento = scanner.nextDouble();

        double litro = valorPagamento / precoLitro;
        long litroarredondado = Math.round(litro);


        System.out.println("Foram enchidos " + litroarredondado + " litros do seu tanque");
        scanner.close();
    }
}
