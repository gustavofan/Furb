import java.util.Scanner;

public class exe04 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite sua primeira nota:");
        double nota01 = scanner.nextDouble();
        System.out.println("Digite sua segunda nota:");
        double nota02 = scanner.nextDouble();
        System.out.println("Digite sua terceita nota:");
        double nota03 = scanner.nextDouble();

        double mediaFinal = (nota01 * 0.5) + (nota02 * 0.3) + (nota03 * 0.2);
        double arredondado = Math.round(mediaFinal * 100.0 ) / 100.0;

        System.out.println("Sua media final foi: " + arredondado);

        scanner.close();

    }
}