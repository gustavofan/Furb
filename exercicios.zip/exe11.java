import java.util.Scanner;

public class exe11 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Informe a temperatua em graus celsius:");
        double temperaturaGrausCelsius = scanner.nextDouble();

        double temperaturaFarenheit = ( temperaturaGrausCelsius * 9 / 5 ) + 32;

        System.out.println(temperaturaFarenheit);

        scanner.close();

    }
}