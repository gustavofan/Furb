import java.util.Scanner;

public class exe08 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double valorDolar = 4.99;

        System.out.println("Quantos dolares você deseja vender?");
        double quantidadeDolar = scanner.nextDouble();

        double valorReceber = quantidadeDolar * valorDolar;

        System.out.println("Você receberá " + valorReceber + " reais");
        scanner.close();

    }
}