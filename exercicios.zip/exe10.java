import java.util.Scanner;

public class exe10 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Qual o valor do primeiro cateto?");
        double cateto01 = scanner.nextDouble();
        System.out.println("Qual o valor do segundo cateto?");
        double cateto02 = scanner.nextDouble();

        double hipotenusa = Math.sqrt(Math.pow(cateto01, 2) + Math.pow(cateto02, 2));
        
        System.out.println("O valor da hipotenusa é: " + Math.sqrt(Math.pow(hipotenusa, 2)));
        scanner.close();


    }
}