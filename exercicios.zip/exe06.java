import java.util.Scanner;

public class exe06 {

    public static void main (String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Qual o peso do seu prato em gramas?");
        double pesoComida = scanner.nextDouble();

        double valorRefeicao = (pesoComida - 750) * 0.25; 

        System.out.println("O preco total foi de: R$ " + valorRefeicao);
        scanner.close();
    }
}