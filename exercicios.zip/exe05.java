import java.util.Scanner;

public class exe05 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int anelChip = 4;
        double anelAlimento = 3.50;

        System.out.println("Quantos frangos têm na sua granja?");
        int quantidadeGalinha = scanner.nextInt();

        double precoTotalAnel = (anelChip * quantidadeGalinha) + ((anelAlimento * 2) + quantidadeGalinha);

        System.out.println("O preco total será: R$" + precoTotalAnel);
        scanner.close();

    }
}