import java.util.Scanner;

public class exe09 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println(" Qual a altura da lata de óleo?");
        double alturaLata = scanner.nextDouble();
        System.out.println("Qual o raio da lata de óleo?");
        double raioLata = scanner.nextDouble();

        double volumeLata = Math.PI * (raioLata * raioLata) * alturaLata;
        double volumeLataArredondado = Math.round(volumeLata * 100.0) / 100.0;

        System.out.println("O volume da lata é " + volumeLataArredondado);
        scanner.close();

    }
}