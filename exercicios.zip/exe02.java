import java.util.Scanner;
public class exe02 {

    public static void main(String[] args) {;
    Scanner scanner = new Scanner (System.in);

    System.out.println("Informe o valor do sapato comprado");
    double valorSapato = scanner.nextDouble();

    double valorDesconto = valorSapato * 0.88;
    double desconto = valorSapato - valorDesconto;

    System.out.println("O valor do desconto é de: R$" + desconto);
    System.out.println("O valor do sapato é: R$" + valorDesconto);
        scanner.close();
    }

}