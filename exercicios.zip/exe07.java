import java.util.Scanner;

public class exe07 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        double refriPequeno = 0.35; 
        double refriMedio = 0.6;
        double refriGrande = 2;

        System.out.println("Informe a quantidade de refrigerante pequeno");
        int compradoRefriPequeno = scanner.nextInt();
        System.out.println("Informe a quantidade de refrigerante medio");
        int compradoRefriMedio = scanner.nextInt();
        System.out.println("Informe a quantidade de refrigerante grande");
        int compradoRefriGrande = scanner.nextInt();

        double  totalComprado = (compradoRefriGrande * refriGrande) + (compradoRefriMedio * refriMedio) + (compradoRefriPequeno * refriPequeno);
        System.out.println("Foram comprados " + totalComprado + " L");
        scanner.close();
    }
}