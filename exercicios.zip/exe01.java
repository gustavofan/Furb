import java.util.Scanner;
public class exe01 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.println("digite o comprimento do retângulo em metros:");
        double comprimento = scanner.nextDouble();
        System.out.println("digite a largura do retângulo em metros:");
        double largura = scanner.nextDouble();
    
        double area = comprimento * largura;
    
        System.out.println("A área do seu terreno é de: " + area + " metros");
        scanner.close();
        
    }
}